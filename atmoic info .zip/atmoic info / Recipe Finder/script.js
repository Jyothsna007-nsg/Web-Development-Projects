// Predefined recipes
const recipes = [
    {
        name: "Tomato Omelette",
        ingredients: ["egg", "tomato", "salt", "pepper"],
        instructions: "Beat eggs with chopped tomato, salt & pepper. Cook on a pan until golden."
    },
    {
        name: "Cheese Sandwich",
        ingredients: ["bread", "cheese", "butter"],
        instructions: "Butter the bread, add cheese, and toast until golden."
    },
    {
        name: "Egg Fried Rice",
        ingredients: ["rice", "egg", "carrot", "peas", "soy sauce"],
        instructions: "Cook rice. Stir-fry veggies and scrambled eggs, then mix with rice and soy sauce."
    },
    {
        name: "Tomato Soup",
        ingredients: ["tomato", "onion", "salt", "pepper", "water"],
        instructions: "Boil tomatoes and onion. Blend and season with salt & pepper."
    }
];

function findRecipes() {
    const input = document.getElementById("ingredientsInput").value.toLowerCase();
    const userIngredients = input.split(",").map(i => i.trim()).filter(i => i !== "");
    const resultsDiv = document.getElementById("results");
    resultsDiv.innerHTML = "";

    if(userIngredients.length === 0){
        resultsDiv.innerHTML = "<p>Please enter some ingredients!</p>";
        return;
    }

    const matchedRecipes = recipes.filter(recipe =>
        recipe.ingredients.every(ing => userIngredients.includes(ing))
    );

    if(matchedRecipes.length === 0){
        resultsDiv.innerHTML = "<p>No recipes found with these ingredients.</p>";
        return;
    }

    matchedRecipes.forEach(recipe => {
        const div = document.createElement("div");
        div.classList.add("recipe");
        div.innerHTML = `<h3>${recipe.name}</h3>
                         <p><strong>Ingredients:</strong> ${recipe.ingredients.join(", ")}</p>
                         <p><strong>Instructions:</strong> ${recipe.instructions}</p>`;
        resultsDiv.appendChild(div);
    });
}
