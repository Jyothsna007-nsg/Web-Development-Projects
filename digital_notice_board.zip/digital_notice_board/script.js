let notices = JSON.parse(localStorage.getItem("notices")) || [];
let container = document.getElementById("noticeContainer");

if (notices.length === 0) {
  container.innerHTML = "<p>No notices available</p>";
}

notices.reverse().forEach(n => {
  let div = document.createElement("div");
  div.className = "notice";
  if (n.priority === "Urgent") div.classList.add("urgent");

  div.innerHTML = `
    <h3>${n.title}</h3>
    <p>${n.message}</p>
    <small>${n.date} | ${n.priority}</small>
  `;

  container.appendChild(div);
});
