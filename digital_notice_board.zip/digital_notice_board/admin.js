let notices = JSON.parse(localStorage.getItem("notices")) || [];

document.getElementById("noticeForm").addEventListener("submit", function(e) {
  e.preventDefault();

  let title = document.getElementById("title").value;
  let message = document.getElementById("message").value;
  let priority = document.getElementById("priority").value;

  let notice = {
    title,
    message,
    priority,
    date: new Date().toLocaleDateString()
  };

  notices.push(notice);
  localStorage.setItem("notices", JSON.stringify(notices));

  alert("Notice Added Successfully!");
  this.reset();
});
