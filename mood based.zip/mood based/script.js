// Define playlists for each mood (you can use local mp3 files or YouTube links)
const playlists = {
  happy: [
   
    "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",
    "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3"
  ],
  sad: [
    "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3",
    "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3"
  ],
  relaxed: [
    "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-5.mp3",
    "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-6.mp3"
  ],
  energetic: [
    "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-7.mp3",
    "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-8.mp3"
  ]
};

let currentIndex = 0;
let currentMood = "";
const audioPlayer = document.getElementById("audioPlayer");
const currentMoodText = document.getElementById("currentMood");

function playMood(mood) {
  currentMood = mood;
  currentIndex = 0;
  currentMoodText.textContent = `Mood: ${mood.charAt(0).toUpperCase() + mood.slice(1)}`;
  playSong();
}

// Play current song
function playSong() {
  if (!currentMood) return;
  audioPlayer.src = playlists[currentMood][currentIndex];
  audioPlayer.play();
}

// Auto play next song when current ends
audioPlayer.addEventListener("ended", () => {
  if (!currentMood) return;
  currentIndex++;
  if (currentIndex >= playlists[currentMood].length) {
    currentIndex = 0; // loop playlist
  }
  playSong();
});
