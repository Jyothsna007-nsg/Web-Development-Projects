const express = require("express");
const bodyParser = require("body-parser");
const { YoutubeTranscript } = require("youtube-transcript");

const app = express();

app.use(bodyParser.json());
app.use(express.static("public"));

app.post("/summary", async (req, res) => {
  let link = req.body.link;

  try {
    // Extract video ID from full YouTube link
    const videoID = link.split("v=")[1]?.split("&")[0];
    if (!videoID) throw new Error("Invalid YouTube link");

    const transcript = await YoutubeTranscript.fetchTranscript(videoID);

    const text = transcript.map(item => item.text).join(" ");

    const summary = text.split(" ").slice(0, 80).join(" ");

    res.json({ summary: [summary] });
  } catch (error) {
    res.json({ summary: ["Summary cannot be generated for this video"] });
  }
});

app.listen(3000, () => {
  console.log("Server running on http://localhost:3000");
});
