function getSummary() {
  const link = document.getElementById("link").value;
  const output = document.getElementById("output");

  if (link.trim() === "") {
    output.innerText = "Please paste a YouTube link";
    return;
  }

  output.innerText = "Loading summary...";

  fetch("/summary", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ link: link })
  })
    .then(response => response.json())
    .then(data => {
      output.innerHTML = "";

      if (!data.summary || data.summary.length === 0) {
        output.innerText = "No summary available";
        return;
      }

      data.summary.forEach((line, index) => {
        output.innerHTML += `<p>${index + 1}. ${line}</p>`;
      });
    })
    .catch(error => {
      output.innerText = "Error getting summary";
      console.error(error);
    });
}
